"use strict";

const ROOM_CAPACITY = 50;
const RESERVATION_HOURS = 5;
const STORAGE_KEYS = {
  shelters: "safehaven_shelters_v2",
  registrations: "safehaven_registrations_v2"
};

const defaultShelters = [
  { id: "s1", name: "Ganga Shelter", category: "human", rooms: 2 },
  { id: "s2", name: "Yamuna Shelter", category: "human", rooms: 2 },
  { id: "s3", name: "Brahmaputra Shelter", category: "human", rooms: 1 },
  { id: "s4", name: "Godavari Animal Shelter", category: "animal", rooms: 2 }
];

function readStorage(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch (error) {
    console.error(`Could not read ${key}:`, error);
    return fallback;
  }
}

let shelters = readStorage(STORAGE_KEYS.shelters, defaultShelters);
let registrations = readStorage(STORAGE_KEYS.registrations, []);

function saveData() {
  localStorage.setItem(STORAGE_KEYS.shelters, JSON.stringify(shelters));
  localStorage.setItem(STORAGE_KEYS.registrations, JSON.stringify(registrations));
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function getUsedBeds(shelterId, roomNumber, category) {
  return registrations
    .filter(record => record.status === "Reserved" && record.category === category)
    .flatMap(record => record.allocations || [])
    .filter(allocation => allocation.shelterId === shelterId && allocation.room === roomNumber)
    .reduce((total, allocation) => total + allocation.beds, 0);
}

function findAllocation(category, quantity) {
  const matchingShelters = shelters.filter(shelter => shelter.category === category);
  const allocations = [];
  let remaining = quantity;

  for (const shelter of matchingShelters) {
    for (let room = 1; room <= shelter.rooms && remaining > 0; room += 1) {
      const available = ROOM_CAPACITY - getUsedBeds(shelter.id, room, category);
      if (available <= 0) continue;

      const beds = Math.min(available, remaining);
      allocations.push({
        shelterId: shelter.id,
        shelterName: shelter.name,
        room,
        beds
      });
      remaining -= beds;
    }
  }

  return remaining === 0 ? allocations : null;
}

function createRegistration(details) {
  const allocations = findAllocation(details.category, details.quantity);
  if (!allocations) {
    showResult("No availability", "There are not enough available beds in the matching shelter category. Please contact the control authority.", false);
    return;
  }

  const now = Date.now();
  const record = {
    id: `SH-${now.toString(36).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`,
    ...details,
    allocations,
    createdAt: now,
    expiresAt: now + RESERVATION_HOURS * 60 * 60 * 1000,
    status: "Reserved"
  };

  registrations.push(record);
  saveData();
  renderAll();
  showResult("Allocation confirmed", buildAllocationMessage(record), true);
}

function buildAllocationMessage(record) {
  const allocationLines = record.allocations.map(allocation => {
    const beds = allocation.beds === 1 ? "bed" : "beds";
    return `<li>${escapeHTML(allocation.shelterName)} — Room ${allocation.room}, ${allocation.beds} ${beds}</li>`;
  }).join("");

  return `
    <p><strong>Reference:</strong> ${escapeHTML(record.id)}</p>
    <p><strong>Registrant:</strong> ${escapeHTML(record.name)}</p>
    <p><strong>Allocation:</strong></p>
    <ul>${allocationLines}</ul>
    <p><strong>Arrival deadline:</strong> ${new Date(record.expiresAt).toLocaleString()}</p>
    <p>The reservation expires after five hours if check-in is not completed. The location button is intentionally disabled in this demo.</p>
  `;
}

function showResult(title, message, success) {
  const result = document.getElementById("result");
  result.classList.remove("hidden");
  result.innerHTML = `<h3>${escapeHTML(title)}</h3>${success ? message : `<p>${escapeHTML(message)}</p>`}`;
  result.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function switchForm(formName) {
  document.querySelectorAll("#view-register form").forEach(form => form.classList.add("hidden"));
  const selectedForm = document.getElementById(`${formName}Form`);
  if (selectedForm) selectedForm.classList.remove("hidden");

  document.querySelectorAll(".subtab").forEach(button => {
    button.classList.toggle("active", button.dataset.form === formName);
  });
  document.getElementById("result").classList.add("hidden");
}

function switchView(viewName) {
  document.querySelectorAll(".view").forEach(view => view.classList.remove("active"));
  document.getElementById(`view-${viewName}`).classList.add("active");

  document.querySelectorAll(".tab").forEach(button => {
    button.classList.toggle("active", button.dataset.view === viewName);
  });
}

function renderFamilyFields() {
  const count = Number(document.getElementById("familyCount").value);
  const container = document.getElementById("familyMembers");
  container.innerHTML = "";

  for (let member = 2; member <= count; member += 1) {
    const label = document.createElement("label");
    label.textContent = `Family member ${member} name`;
    const input = document.createElement("input");
    input.name = "memberName";
    input.required = true;
    input.maxLength = 70;
    input.placeholder = `Member ${member} full name`;
    label.appendChild(input);
    container.appendChild(label);
  }
}

function renderShelters() {
  const list = document.getElementById("shelterList");
  list.innerHTML = "";

  shelters.forEach(shelter => {
    let totalBeds = shelter.rooms * ROOM_CAPACITY;
    let occupiedBeds = 0;

    for (let room = 1; room <= shelter.rooms; room += 1) {
      occupiedBeds += getUsedBeds(shelter.id, room, shelter.category);
    }

    const card = document.createElement("article");
    card.className = "shelter-card";
    card.innerHTML = `
      <h3>${escapeHTML(shelter.name)}</h3>
      <p>Category: ${shelter.category === "human" ? "People / families" : "Domestic animals"}</p>
      <p>Rooms: ${shelter.rooms} · Capacity: ${totalBeds}</p>
      <p>Occupied: ${occupiedBeds} · Available: ${totalBeds - occupiedBeds}</p>
      <p>Room capacity: ${ROOM_CAPACITY} ${shelter.category === "human" ? "beds" : "animal spaces"}</p>
      <button class="primary location-button" type="button" disabled title="Location is not enabled in this prototype">View location (not available)</button>
    `;
    list.appendChild(card);
  });
}

function renderRecords() {
  const body = document.getElementById("recordsBody");
  body.innerHTML = "";

  if (registrations.length === 0) {
    body.innerHTML = '<tr><td colspan="6">No registrations yet.</td></tr>';
    return;
  }

  [...registrations].reverse().forEach(record => {
    const allocationText = record.allocations.map(item =>
      `${item.shelterName}, Room ${item.room} (${item.beds})`
    ).join("; ");
    const remaining = record.status === "Reserved"
      ? formatRemaining(record.expiresAt - Date.now())
      : "—";
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHTML(record.id)}</td>
      <td>${escapeHTML(record.name)}</td>
      <td>${escapeHTML(record.type)}</td>
      <td>${escapeHTML(allocationText)}</td>
      <td>${escapeHTML(record.status)}</td>
      <td>${remaining}</td>
    `;
    body.appendChild(row);
  });
}

function formatRemaining(milliseconds) {
  if (milliseconds <= 0) return "Expired";
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${hours}h ${minutes}m ${seconds}s`;
}

function expireReservations() {
  const now = Date.now();
  let changed = false;

  registrations.forEach(record => {
    if (record.status === "Reserved" && now >= record.expiresAt) {
      record.status = "Expired — beds released";
      changed = true;
    }
  });

  if (changed) saveData();
}

function renderStats() {
  const humanShelters = shelters.filter(shelter => shelter.category === "human");
  const totalHumanBeds = humanShelters.reduce((sum, shelter) => sum + shelter.rooms * ROOM_CAPACITY, 0);
  const occupiedHumanBeds = registrations
    .filter(record => record.status === "Reserved" && record.category === "human")
    .reduce((sum, record) => sum + record.quantity, 0);
  const peopleRegistered = registrations
    .filter(record => record.category === "human" && record.status === "Reserved")
    .reduce((sum, record) => sum + record.quantity, 0);
  const animalRegistrations = registrations.filter(record => record.category === "animal").length;

  document.getElementById("statShelters").textContent = shelters.length;
  document.getElementById("statBeds").textContent = Math.max(0, totalHumanBeds - occupiedHumanBeds);
  document.getElementById("statPeople").textContent = peopleRegistered;
  document.getElementById("statAnimals").textContent = animalRegistrations;
}

function renderAll() {
  renderStats();
  renderShelters();
  renderRecords();
}

document.querySelectorAll(".tab").forEach(button => {
  button.addEventListener("click", () => switchView(button.dataset.view));
});

document.querySelectorAll(".subtab").forEach(button => {
  button.addEventListener("click", () => switchForm(button.dataset.form));
});

document.getElementById("familyCount").addEventListener("change", renderFamilyFields);

document.getElementById("individualForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  createRegistration({
    name: form.get("name").trim(),
    phone: form.get("phone").trim(),
    age: Number(form.get("age")),
    needs: form.get("needs"),
    type: "Individual",
    category: "human",
    quantity: 1
  });
  event.currentTarget.reset();
});

document.getElementById("familyForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const count = Number(form.get("count"));
  const memberNames = form.getAll("memberName").map(name => name.trim()).filter(Boolean);

  if (memberNames.length !== count - 1) {
    showResult("Check family details", "Please enter the name of every family member, excluding the family head.", false);
    return;
  }

  const head = form.get("head").trim();
  createRegistration({
    name: `${head} and family`,
    members: [head, ...memberNames],
    phone: form.get("phone").trim(),
    needs: form.get("needs"),
    type: "Family",
    category: "human",
    quantity: count
  });
  event.currentTarget.reset();
  renderFamilyFields();
});

document.getElementById("animalForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  createRegistration({
    name: form.get("owner").trim(),
    phone: form.get("phone").trim(),
    animalType: form.get("type").trim(),
    type: `Animals: ${form.get("type").trim()}`,
    category: "animal",
    quantity: Number(form.get("quantity"))
  });
  event.currentTarget.reset();
});

document.getElementById("shelterForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = form.get("name").trim();
  const duplicate = shelters.some(shelter => shelter.name.toLowerCase() === name.toLowerCase());

  if (duplicate) {
    alert("A shelter with this name already exists.");
    return;
  }

  shelters.push({
    id: `shelter-${Date.now()}`,
    name,
    category: form.get("category"),
    rooms: Number(form.get("rooms"))
  });
  saveData();
  renderAll();
  event.currentTarget.reset();
  alert("Shelter added successfully.");
});

// Start with the first family member field hidden because the default family size is two.
renderFamilyFields();
expireReservations();
renderAll();
setInterval(() => {
  expireReservations();
  renderAll();
}, 1000);
