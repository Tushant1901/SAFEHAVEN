SAFEHAVEN — Emergency Shelter Allocation System

FILES
- index5.html: main website page
- style5.css: design and responsive layout
- script5.js: registration, automatic allocation and demo data

HOW TO RUN
1. Keep all three files in the same folder.
2. Open index5.html in a browser, or open the folder in VS Code and use Live Server.
3. For GitHub Pages, rename index5.html to index.html before publishing, because GitHub Pages expects index.html as the default entry page.

FEATURES
- Individual registration
- Family registration for up to 10 members
- Separate domestic-animal registration
- Automatic bed allocation
- 50 beds per room
- Family same-room preference, then split across rooms if needed
- Indian-river-inspired shelter names
- Add shelters in the Control Center
- Allocation records and five-hour reservation expiry
- Location button shown but disabled

IMPORTANT LIMITATIONS
This is a front-end student-project demo. Data is stored only in the current browser using localStorage. It is not shared between visitors or devices. There is no secure administrator login, central database, real-time coordination, or actual arrival verification. The five-hour expiry is a demo timer, not a real check-in system. Do not enter real personal or emergency information.
